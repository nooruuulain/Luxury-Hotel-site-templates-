// Luxury Haven Hotel - JavaScript Functionality

// DOM Content Loaded Event
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all functionality
    initializeNavigation();
    initializeRoomFiltering();
    initializeFormValidation();
    initializeSmoothScrolling();
    initializeAnimations();
    setMinDateForDateInputs();
});

// Navigation System
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const pageSections = document.querySelectorAll('.page-section');
    
    // Hide all sections except home initially
    pageSections.forEach(section => {
        if (section.id !== 'home') {
            section.classList.add('d-none');
        }
    });
    
    // Add click event listeners to navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                // Hide all sections
                pageSections.forEach(section => {
                    section.classList.add('d-none');
                });
                
                // Show target section
                targetSection.classList.remove('d-none');
                
                // Update active navigation link
                navLinks.forEach(navLink => navLink.classList.remove('active'));
                this.classList.add('active');
                
                // Scroll to top of the page
                window.scrollTo(0, 0);
            }
        });
    });
    
    // Set home as active by default
    document.querySelector('a[href="#home"]').classList.add('active');
}

// Room Filtering System
function initializeRoomFiltering() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const roomItems = document.querySelectorAll('.room-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter rooms
            roomItems.forEach(item => {
                const category = item.getAttribute('data-category');
                
                if (filter === 'all' || category === filter) {
                    item.style.display = 'block';
                    item.style.animation = 'fadeInUp 0.6s ease-out';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });
}

// Form Validation System
function initializeFormValidation() {
    // Booking Form Validation
    const bookingForm = document.getElementById('bookingForm');
    if (bookingForm) {
        bookingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (validateBookingForm()) {
                handleBookingSubmission();
            }
        });
    }
    
    // Contact Form Validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (validateContactForm()) {
                handleContactSubmission();
            }
        });
    }
    
    // Real-time validation
    initializeRealTimeValidation();
}

// Booking Form Validation
function validateBookingForm() {
    const form = document.getElementById('bookingForm');
    let isValid = true;
    
    // Reset previous validation states
    form.classList.remove('was-validated');
    
    // Validate required fields
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
            field.classList.add('is-valid');
        }
    });
    
    // Validate email format
    const emailField = document.getElementById('email');
    if (emailField.value && !isValidEmail(emailField.value)) {
        emailField.classList.add('is-invalid');
        isValid = false;
    }
    
    // Validate phone format
    const phoneField = document.getElementById('phone');
    if (phoneField.value && !isValidPhone(phoneField.value)) {
        phoneField.classList.add('is-invalid');
        isValid = false;
    }
    
    // Validate dates
    const checkInField = document.getElementById('checkIn');
    const checkOutField = document.getElementById('checkOut');
    
    if (checkInField.value && checkOutField.value) {
        const checkIn = new Date(checkInField.value);
        const checkOut = new Date(checkOutField.value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (checkIn < today) {
            checkInField.classList.add('is-invalid');
            isValid = false;
        } else {
            checkInField.classList.remove('is-invalid');
            checkInField.classList.add('is-valid');
        }
        
        if (checkOut <= checkIn) {
            checkOutField.classList.add('is-invalid');
            isValid = false;
        } else {
            checkOutField.classList.remove('is-invalid');
            checkOutField.classList.add('is-valid');
        }
    }
    
    form.classList.add('was-validated');
    return isValid;
}

// Contact Form Validation
function validateContactForm() {
    const form = document.getElementById('contactForm');
    let isValid = true;
    
    // Reset previous validation states
    form.classList.remove('was-validated');
    
    // Validate required fields
    const requiredFields = form.querySelectorAll('[required]');
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
            field.classList.add('is-valid');
        }
    });
    
    // Validate email format
    const emailField = document.getElementById('contactEmail');
    if (emailField.value && !isValidEmail(emailField.value)) {
        emailField.classList.add('is-invalid');
        isValid = false;
    }
    
    form.classList.add('was-validated');
    return isValid;
}

// Real-time Validation
function initializeRealTimeValidation() {
    // Booking form real-time validation
    const bookingFields = document.querySelectorAll('#bookingForm input, #bookingForm select');
    bookingFields.forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });
        
        field.addEventListener('input', function() {
            if (this.classList.contains('is-invalid')) {
                validateField(this);
            }
        });
    });
    
    // Contact form real-time validation
    const contactFields = document.querySelectorAll('#contactForm input, #contactForm textarea');
    contactFields.forEach(field => {
        field.addEventListener('blur', function() {
            validateField(this);
        });
        
        field.addEventListener('input', function() {
            if (this.classList.contains('is-invalid')) {
                validateField(this);
            }
        });
    });
}

// Individual Field Validation
function validateField(field) {
    const value = field.value.trim();
    
    // Remove previous validation classes
    field.classList.remove('is-valid', 'is-invalid');
    
    // Check if required field is empty
    if (field.hasAttribute('required') && !value) {
        field.classList.add('is-invalid');
        return false;
    }
    
    // Email validation
    if (field.type === 'email' && value && !isValidEmail(value)) {
        field.classList.add('is-invalid');
        return false;
    }
    
    // Phone validation
    if (field.type === 'tel' && value && !isValidPhone(value)) {
        field.classList.add('is-invalid');
        return false;
    }
    
    // Date validation for check-in
    if (field.id === 'checkIn' && value) {
        const checkIn = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (checkIn < today) {
            field.classList.add('is-invalid');
            return false;
        }
    }
    
    // Date validation for check-out
    if (field.id === 'checkOut' && value) {
        const checkInField = document.getElementById('checkIn');
        if (checkInField.value) {
            const checkIn = new Date(checkInField.value);
            const checkOut = new Date(value);
            
            if (checkOut <= checkIn) {
                field.classList.add('is-invalid');
                return false;
            }
        }
    }
    
    // If all validations pass
    if (value) {
        field.classList.add('is-valid');
    }
    
    return true;
}

// Utility Functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
}

// Set Minimum Date for Date Inputs
function setMinDateForDateInputs() {
    const today = new Date().toISOString().split('T')[0];
    
    const checkInField = document.getElementById('checkIn');
    if (checkInField) {
        checkInField.setAttribute('min', today);
    }
    
    const checkOutField = document.getElementById('checkOut');
    if (checkOutField) {
        checkOutField.setAttribute('min', today);
    }
}

// Handle Booking Submission
function handleBookingSubmission() {
    // Collect form data
    const formData = {
        firstName: document.getElementById('firstName').value,
        lastName: document.getElementById('lastName').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        checkIn: document.getElementById('checkIn').value,
        checkOut: document.getElementById('checkOut').value,
        roomType: document.getElementById('roomType').value,
        guests: document.getElementById('guests').value,
        specialRequests: document.getElementById('specialRequests').value
    };
    
    // Populate modal with booking details
    document.getElementById('modalGuestName').textContent = `${formData.firstName} ${formData.lastName}`;
    document.getElementById('modalEmail').textContent = formData.email;
    document.getElementById('modalPhone').textContent = formData.phone;
    document.getElementById('modalCheckIn').textContent = formatDate(formData.checkIn);
    document.getElementById('modalCheckOut').textContent = formatDate(formData.checkOut);
    document.getElementById('modalRoomType').textContent = getRoomTypeDisplayName(formData.roomType);
    document.getElementById('modalGuests').textContent = `${formData.guests} Guest${formData.guests > 1 ? 's' : ''}`;
    
    // Show booking confirmation modal
    const bookingModal = new bootstrap.Modal(document.getElementById('bookingModal'));
    bookingModal.show();
    
    // Reset form
    document.getElementById('bookingForm').reset();
    
    // Remove validation classes
    const formFields = document.querySelectorAll('#bookingForm input, #bookingForm select, #bookingForm textarea');
    formFields.forEach(field => {
        field.classList.remove('is-valid', 'is-invalid');
    });
}

// Handle Contact Submission
function handleContactSubmission() {
    // Collect form data
    const formData = {
        name: document.getElementById('contactName').value,
        email: document.getElementById('contactEmail').value,
        subject: document.getElementById('contactSubject').value,
        message: document.getElementById('contactMessage').value
    };
    
    // Show success message
    showNotification('Thank you for your message! We will get back to you soon.', 'success');
    
    // Reset form
    document.getElementById('contactForm').reset();
    
    // Remove validation classes
    const formFields = document.querySelectorAll('#contactForm input, #contactForm textarea');
    formFields.forEach(field => {
        field.classList.remove('is-valid', 'is-invalid');
    });
}

// Utility Functions
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

function getRoomTypeDisplayName(roomType) {
    const roomTypes = {
        'single': 'Single Room',
        'double': 'Double Room',
        'deluxe': 'Deluxe Room',
        'suite': 'Luxury Suite',
        'family': 'Family Room',
        'executive': 'Executive Suite'
    };
    return roomTypes[roomType] || roomType;
}

// Smooth Scrolling
function initializeSmoothScrolling() {
    // Smooth scroll for anchor links within the same page
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Skip if it's a navigation link (handled by navigation system)
            if (this.classList.contains('nav-link')) {
                return;
            }
            
            e.preventDefault();
            const targetElement = document.querySelector(href);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Animation System
function initializeAnimations() {
    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.amenity-card, .room-card, .contact-item');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(el);
    });
}

// Notification System
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = `
        top: 20px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `;
    
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Add to page
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Mobile Menu Toggle Enhancement
function initializeMobileMenu() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        navbarToggler.addEventListener('click', function() {
            // Add smooth animation to mobile menu
            if (navbarCollapse.classList.contains('show')) {
                navbarCollapse.style.transition = 'all 0.3s ease-out';
            } else {
                navbarCollapse.style.transition = 'all 0.3s ease-in';
            }
        });
        
        // Close mobile menu when clicking on a link
        const mobileNavLinks = navbarCollapse.querySelectorAll('.nav-link');
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth < 992) {
                    navbarCollapse.classList.remove('show');
                }
            });
        });
    }
}

// Initialize mobile menu
document.addEventListener('DOMContentLoaded', initializeMobileMenu);

// Performance Optimization: Lazy Loading for Images
function initializeLazyLoading() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        const lazyImages = document.querySelectorAll('img[data-src]');
        lazyImages.forEach(img => imageObserver.observe(img));
    }
}

// Initialize lazy loading
document.addEventListener('DOMContentLoaded', initializeLazyLoading);

// Error Handling
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    showNotification('An error occurred. Please refresh the page.', 'danger');
});

// Console Log for Development
console.log('Luxury Haven Hotel - Website Loaded Successfully!');
console.log('Features: Navigation, Room Filtering, Form Validation, Animations');
