# Luxury Haven Hotel Website

A responsive and modern hotel website built with HTML, CSS (Bootstrap 5), and JavaScript. This project showcases a complete hotel booking system with multiple pages, interactive features, and a professional design.

## 🌟 Features

### 📱 Responsive Design
- Fully responsive layout for desktop, tablet, and mobile devices
- Bootstrap 5 framework for modern, mobile-first design
- Optimized for all screen sizes and orientations

### 🏠 Multiple Pages
- **Home Page**: Hero carousel, about section, amenities, and photo gallery
- **Rooms Page**: Room categories with filtering (Single, Double, Suite)
- **Booking Page**: Comprehensive booking form with validation
- **Contact Page**: Contact form and Google Maps integration

### 🎨 Modern UI/UX
- Elegant design with luxury hotel aesthetic
- Smooth animations and transitions
- Professional color scheme and typography
- Interactive hover effects and micro-interactions

### ⚡ JavaScript Functionality
- **Navigation System**: Single-page application with smooth page transitions
- **Room Filtering**: Dynamic filtering by room category
- **Form Validation**: Real-time validation for booking and contact forms
- **Booking System**: Complete booking flow with confirmation modal
- **Smooth Scrolling**: Enhanced user experience with smooth scrolling
- **Mobile Menu**: Responsive mobile navigation

### 🎯 Key Components
- **Hero Carousel**: Image slider with call-to-action buttons
- **Room Cards**: Detailed room information with pricing and amenities
- **Booking Form**: Comprehensive form with date validation
- **Contact Form**: User-friendly contact form with validation
- **Google Maps**: Embedded map for hotel location
- **Footer**: Social media links and contact information

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- No server setup required - runs entirely in the browser

### Installation
1. Clone or download the project files
2. Open `index.html` in your web browser
3. The website will load with all functionality ready to use

### File Structure
```
luxury-haven-hotel/
├── index.html          # Main HTML file with all pages
├── styles.css          # Custom CSS styles and animations
├── script.js           # JavaScript functionality
├── images/             # Image assets (if any)
└── README.md           # Project documentation
```

## 🎮 How to Use

### Navigation
- Use the top navigation bar to switch between pages
- The website uses a single-page application approach
- Smooth transitions between different sections

### Room Booking
1. Navigate to the "Book Now" page
2. Fill out the booking form with your details
3. Select room type, dates, and number of guests
4. Submit the form to see the booking confirmation modal

### Room Filtering
1. Go to the "Rooms" page
2. Use the filter buttons to view specific room categories
3. Click "Book Now" on any room to go to the booking form

### Contact Form
1. Navigate to the "Contact" page
2. Fill out the contact form with your message
3. Submit to send your inquiry

## 🛠️ Technical Details

### Technologies Used
- **HTML5**: Semantic markup and structure
- **CSS3**: Custom styling with CSS variables and animations
- **Bootstrap 5**: Responsive grid system and components
- **JavaScript (ES6+)**: Modern JavaScript with modular functions
- **Font Awesome**: Icon library for visual elements
- **Google Fonts**: Typography (Playfair Display, Inter)

### Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

### Performance Features
- Lazy loading for images
- Optimized animations with CSS transforms
- Efficient DOM manipulation
- Minimal external dependencies

## 🎨 Customization

### Colors
The website uses CSS custom properties for easy color customization:
```css
:root {
    --primary-color: #1e3a8a;    /* Main brand color */
    --secondary-color: #f59e0b;  /* Accent color */
    --accent-color: #10b981;     /* Success/CTA color */
    --dark-color: #1f2937;       /* Dark text */
    --light-color: #f8fafc;      /* Light backgrounds */
}
```

### Content
- Update hotel information in the HTML files
- Replace placeholder images with actual hotel photos
- Modify room types, prices, and amenities
- Update contact information and Google Maps embed

### Styling
- Modify `styles.css` for custom design changes
- Adjust animations and transitions
- Customize responsive breakpoints
- Add new CSS classes as needed

## 📱 Mobile Optimization

### Responsive Features
- Mobile-first design approach
- Touch-friendly navigation
- Optimized form inputs for mobile devices
- Responsive image sizing
- Mobile-specific animations

### Mobile Menu
- Hamburger menu for small screens
- Smooth slide-in animation
- Auto-close on navigation
- Touch-friendly button sizes

## 🔧 Form Validation

### Booking Form Validation
- Required field validation
- Email format validation
- Phone number validation
- Date validation (check-in must be future, check-out must be after check-in)
- Real-time validation feedback

### Contact Form Validation
- Required field validation
- Email format validation
- Real-time validation feedback

## 🎭 Animations and Effects

### CSS Animations
- Fade-in effects for page elements
- Hover animations for interactive elements
- Smooth transitions for all interactive states
- Scroll-triggered animations

### JavaScript Enhancements
- Smooth page transitions
- Dynamic content filtering
- Form validation animations
- Modal animations

## 🚀 Deployment

### Local Development
- Simply open `index.html` in a web browser
- No build process or compilation required
- All features work immediately

### Web Hosting
- Upload all files to your web hosting service
- Ensure all file paths are maintained
- Test functionality after deployment

### CDN Dependencies
The website uses the following CDN resources:
- Bootstrap 5 CSS and JS
- Font Awesome icons
- Google Fonts

## 📋 Browser Compatibility

### Supported Features
- CSS Grid and Flexbox
- CSS Custom Properties (variables)
- ES6+ JavaScript features
- Intersection Observer API
- CSS animations and transitions

### Fallbacks
- Graceful degradation for older browsers
- Progressive enhancement approach
- Cross-browser compatible CSS

## 🤝 Contributing

### Development Guidelines
- Maintain responsive design principles
- Follow existing code structure
- Test on multiple devices and browsers
- Ensure accessibility standards are met

### Code Style
- Use semantic HTML elements
- Follow CSS naming conventions
- Write clean, commented JavaScript
- Maintain consistent formatting

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🙏 Acknowledgments

- Bootstrap team for the responsive framework
- Font Awesome for the icon library
- Google Fonts for typography
- Unsplash for placeholder images

## 📞 Support

For questions or support regarding this project:
- Check the code comments for implementation details
- Review the browser console for any JavaScript errors
- Ensure all files are properly linked and accessible

---

**Built with ❤️ for luxury hotel experiences**

*This website demonstrates modern web development practices and provides a complete solution for hotel booking and information display.*
